# train.py
import torch
import torch.optim as optim
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from model import VGG, cfg_vgg6

# ------------------ Helper Functions ------------------ #
def evaluate(model, loader, device):
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for data, target in loader:
            data, target = data.to(device), target.to(device)
            outputs = model(data)
            _, predicted = outputs.max(1)
            total += target.size(0)
            correct += predicted.eq(target).sum().item()
    return 100. * correct / total

def train_model(model, train_loader, test_loader, device, epochs=10, lr=0.001):
    model = model.to(device)
    optimizer = optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()
    train_acc_list, test_acc_list = [], []

    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        for data, target in train_loader:
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()
            outputs = model(data)
            loss = criterion(outputs, target)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        train_acc = evaluate(model, train_loader, device)
        test_acc = evaluate(model, test_loader, device)
        train_acc_list.append(train_acc)
        test_acc_list.append(test_acc)
        print(f"Epoch {epoch+1}: Train Acc={train_acc:.2f}%, Test Acc={test_acc:.2f}%")

    return train_acc_list, test_acc_list


# ------------------ Main ------------------ #
if __name__ == "__main__":
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    transform_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914,0.4822,0.4465),(0.2023,0.1994,0.2010))
    ])
    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914,0.4822,0.4465),(0.2023,0.1994,0.2010))
    ])

    trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform_train)
    testset = torchvision.datasets.CIFAR10(root='./data', train=False, download=True, transform=transform_test)
    train_loader = torch.utils.data.DataLoader(trainset, batch_size=64, shuffle=True, num_workers=0)
    test_loader = torch.utils.data.DataLoader(testset, batch_size=64, shuffle=False, num_workers=0)

    activations = ['relu', 'sigmoid', 'tanh', 'silu', 'gelu']
    results = {}

    for act in activations:
        print(f"\nTraining with activation: {act}")
        model = VGG(cfg_vgg6, activation=act)
        train_acc, test_acc = train_model(model, train_loader, test_loader, device, epochs=10, lr=0.001)
        results[act] = {'train_acc': train_acc, 'test_acc': test_acc}

        # Save model after each activation function training
        torch.save(model.state_dict(), f"vgg6_{act}.pth")

    plt.figure(figsize=(8,5))
    for act in activations:
        plt.plot(results[act]['test_acc'], label=act)
    plt.xlabel("Epochs")
    plt.ylabel("Test Accuracy (%)")
    plt.title("VGG6 CIFAR-10: Activation Function Comparison")
    plt.legend()
    plt.savefig("activation_comparison.png")
    plt.show()
