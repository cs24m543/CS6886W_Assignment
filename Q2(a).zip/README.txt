1.For local environment run following

pip install -r requirement.txt
pip install pandas

2.To find performance with best activation function run following

python .\test.py