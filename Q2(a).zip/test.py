# test.py
import torch
import torchvision
import torchvision.transforms as transforms
from model import VGG, cfg_vgg6

def evaluate(model, loader, device):
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for data, target in loader:
            data, target = data.to(device), target.to(device)
            outputs = model(data)
            _, predicted = outputs.max(1)
            total += target.size(0)
            correct += predicted.eq(target).sum().item()
    return 100. * correct / total

if __name__ == "__main__":
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
    ])
    testset = torchvision.datasets.CIFAR10(root='./data', train=False, download=True, transform=transform_test)
    test_loader = torch.utils.data.DataLoader(testset, batch_size=64, shuffle=False, num_workers=0)

    activations = ['relu', 'tanh', 'sigmoid','silu','gelu']  # Add more if needed

    for activation in activations:
        try:
            model = VGG(cfg_vgg6, activation=activation)
            model.load_state_dict(torch.load(f"vgg6_{activation}.pth", map_location=device))
            model = model.to(device)

            test_acc = evaluate(model, test_loader, device)
            print(f"Test Accuracy for activation={activation}: {test_acc:.2f}%")
        except FileNotFoundError:
            print(f"Model file for activation '{activation}' not found (vgg6_{activation}.pth). Skipping.")
