# test.py
import torch
from model import build_vgg
from torchvision import datasets, transforms
from torch.utils.data import DataLoader

def get_test_loader(batch_size=100):
    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2023, 0.1994, 0.2010))
    ])
    testset = datasets.CIFAR10('./data', train=False,
                               transform=transform_test, download=True)
    return DataLoader(testset, batch_size=batch_size, shuffle=False, num_workers=10)

def test_model(activation='gelu', model_path=None):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = build_vgg(activation=activation).to(device)
    if model_path is None:
        model_path = f'checkpoints/best_model_{activation}.pth'
    model.load_state_dict(torch.load(model_path, map_location=device))
    test_loader = get_test_loader(batch_size=100)

    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            outputs = model(data)
            _, predicted = outputs.max(1)
            total += target.size(0)
            correct += predicted.eq(target).sum().item()
    acc = 100. * correct / total
    print(f"✅ Test Accuracy ({activation.upper()}): {acc:.2f}%")

if __name__ == "__main__":
    for act in ['gelu']:
        test_model(activation=act)
