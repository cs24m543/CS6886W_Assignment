# train.py
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from model import build_vgg
import random
import numpy as np
from PIL import Image, ImageEnhance, ImageOps
import os

# ----------------- Data Augmentation Classes -----------------
class Cutout(object):
    def __init__(self, n_holes, length):
        self.n_holes = n_holes
        self.length = length

    def __call__(self, img):
        h, w = img.size(1), img.size(2)
        mask = np.ones((h, w), np.float32)
        for n in range(self.n_holes):
            y, x = np.random.randint(h), np.random.randint(w)
            y1, y2 = np.clip(y - self.length // 2, 0, h), np.clip(y + self.length // 2, 0, h)
            x1, x2 = np.clip(x - self.length // 2, 0, w), np.clip(x + self.length // 2, 0, w)
            mask[y1:y2, x1:x2] = 0.
        mask = torch.from_numpy(mask).expand_as(img)
        return img * mask


class SubPolicy(object):
    def __init__(self, p1, operation1, magnitude_idx1, p2, operation2, magnitude_idx2, fillcolor=(128, 128, 128)):
        self.p1, self.p2 = p1, p2
        self.operation1, self.operation2 = operation1, operation2
        self.magnitude_idx1, self.magnitude_idx2 = magnitude_idx1, magnitude_idx2
        self.fillcolor = fillcolor
        self.init = False

    def __call__(self, img):
        ranges = {
            "rotate": np.linspace(0, 30, 10),
            "color": np.linspace(0.0, 0.9, 10),
            "posterize": np.round(np.linspace(8, 4, 10), 0).astype(int),
            "solarize": np.linspace(256, 0, 10),
            "contrast": np.linspace(0.0, 0.9, 10),
            "sharpness": np.linspace(0.0, 0.9, 10),
            "brightness": np.linspace(0.0, 0.9, 10),
            "equalize": [0]*10,
            "invert": [0]*10
        }

        func = {
            "rotate": lambda img, mag: img.rotate(mag * random.choice([-1, 1])),
            "color": lambda img, mag: ImageEnhance.Color(img).enhance(1 + mag * random.choice([-1, 1])),
            "posterize": lambda img, mag: ImageOps.posterize(img, mag),
            "solarize": lambda img, mag: ImageOps.solarize(img, mag),
            "contrast": lambda img, mag: ImageEnhance.Contrast(img).enhance(1 + mag * random.choice([-1, 1])),
            "sharpness": lambda img, mag: ImageEnhance.Sharpness(img).enhance(1 + mag * random.choice([-1, 1])),
            "brightness": lambda img, mag: ImageEnhance.Brightness(img).enhance(1 + mag * random.choice([-1, 1])),
            "equalize": lambda img, mag: ImageOps.equalize(img),
            "invert": lambda img, mag: ImageOps.invert(img)
        }

        if random.random() < self.p1:
            img = func[self.operation1](img, ranges[self.operation1][self.magnitude_idx1])
        if random.random() < self.p2:
            img = func[self.operation2](img, ranges[self.operation2][self.magnitude_idx2])
        return img


class CIFAR10Policy(object):
    def __init__(self, fillcolor=(128, 128, 128)):
        self.policies = [
            SubPolicy(0.1, "invert", 7, 0.2, "contrast", 6, fillcolor),
            SubPolicy(0.7, "rotate", 2, 0.3, "color", 9, fillcolor),
            SubPolicy(0.8, "sharpness", 1, 0.9, "brightness", 3, fillcolor),
        ]

    def __call__(self, img):
        policy = random.choice(self.policies)
        return policy(img)

# ----------------- Data Loader -----------------
def get_cifar10(batch_size=100, num_workers=10, use_cutout=True):
    transform_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        CIFAR10Policy(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2023, 0.1994, 0.2010)),
        Cutout(n_holes=1, length=16)
    ])


    train_data = datasets.CIFAR10('./data', train=True, transform=transform_train, download=True)
    train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True, num_workers=10)
    return train_loader

# ----------------- Training -----------------
def evaluate(model, loader, device):
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for data, target in loader:
            data, target = data.to(device), target.to(device)
            outputs = model(data)
            _, predicted = outputs.max(1)
            total += target.size(0)
            correct += predicted.eq(target).sum().item()
    return 100. * correct / total


def train_model(activation='gelu', epochs=10, lr=0.005, batch_size=100, batch_norm=True, optimizer_type='nadam', momentum=0.9, num_workers=10, use_cutout=True):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = build_vgg(activation=activation).to(device)
    train_loader = get_cifar10(batch_size)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.NAdam(model.parameters(), lr=lr)
    best_acc = 0
    os.makedirs('checkpoints', exist_ok=True)
    save_path = f'checkpoints/best_model_{activation}.pth'

    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        for data, target in train_loader:
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()
            outputs = model(data)
            loss = criterion(outputs, target)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        train_acc = evaluate(model, train_loader, device)
        print(f"Epoch {epoch+1}/{epochs} | Activation: {activation.upper()} | Loss: {running_loss/len(train_loader):.4f} | Train Acc: {train_acc:.2f}%")

        if train_acc > best_acc:
            best_acc = train_acc
            torch.save(model.state_dict(), save_path)

    print(f"\n✅ Best Training Accuracy ({activation}): {best_acc:.2f}%\nModel saved at {save_path}")


if __name__ == "__main__":
    for act in ['gelu']:
        print(f"\n==== Training with GeLU and Nadam ====")
        train_model()
