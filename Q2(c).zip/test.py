# test.py
import torch
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from model import build_vgg
import os

def load_cifar10(batch_size=128, num_workers=10):
    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2023, 0.1994, 0.2010))
    ])
    test_data = datasets.CIFAR10('./data', train=False, transform=transform_test, download=True)
    test_loader = DataLoader(test_data, batch_size=batch_size, shuffle=False, num_workers=num_workers)
    return test_loader

def evaluate(model, loader, device):
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for data, target in loader:
            data, target = data.to(device), target.to(device)
            outputs = model(data)
            _, predicted = outputs.max(1)
            total += target.size(0)
            correct += predicted.eq(target).sum().item()
    return 100. * correct / total

def test_model(model_path, activation='gelu', batch_norm=True, batch_size=128, num_workers=10):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = build_vgg(activation=activation, batch_norm=batch_norm)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.to(device)

    test_loader = load_cifar10(batch_size=batch_size, num_workers=num_workers)
    acc = evaluate(model, test_loader, device)
    print(f"✅ {os.path.basename(model_path)} | Test Accuracy: {acc:.2f}%")

if __name__ == "__main__":
    model_dir = 'checkpoints'
    for file in os.listdir(model_dir):
        if file.endswith('.pth'):
            test_model(os.path.join(model_dir, file))
