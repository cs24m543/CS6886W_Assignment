# model.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import math

# --- Model Definition (VGG-like) ---
class VGG(nn.Module):
    def __init__(self, features, num_classes=10):
        super(VGG, self).__init__()
        self.features = features
        self.classifier = nn.Linear(128, num_classes)
        self._initialize_weights()

    def forward(self, x):
        x = self.features(x)
        x = F.adaptive_avg_pool2d(x, (1, 1))
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, nonlinearity='relu')
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()


# --- Helper: Build convolutional layers ---
def make_layers(cfg, activation='gelu', batch_norm=True):
    act_fn = {
        'relu': nn.ReLU(inplace=True),
        'sigmoid': nn.Sigmoid(),
        'tanh': nn.Tanh(),
        'silu': nn.SiLU(),
        'gelu': nn.GELU(),
    }[activation]

    layers = []
    in_channels = 3
    for v in cfg:
        if v == 'M':
            layers += [nn.MaxPool2d(kernel_size=2, stride=2)]
        else:
            conv2d = nn.Conv2d(in_channels, v, kernel_size=3, padding=1)
            if batch_norm:
                layers += [conv2d, nn.BatchNorm2d(v), act_fn]
            else:
                layers += [conv2d, act_fn]
            in_channels = v
    return nn.Sequential(*layers)


# --- VGG Builder ---
def build_vgg(cfg=None, num_classes=10, activation='gelu', batch_norm=True):
    if cfg is None:
        cfg = [64, 64, 'M', 128, 128, 'M']  # VGG-6
    return VGG(make_layers(cfg, activation=activation, batch_norm=batch_norm), num_classes=num_classes)
