# train.py
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from model import build_vgg
import numpy as np
import os
from PIL import Image, ImageEnhance, ImageOps
import random

# ----------------- Data Augmentation -----------------
class Cutout(object):
    def __init__(self, n_holes=1, length=16):
        self.n_holes = n_holes
        self.length = length

    def __call__(self, img):
        h, w = img.size(1), img.size(2)
        mask = np.ones((h, w), np.float32)
        for _ in range(self.n_holes):
            y, x = np.random.randint(h), np.random.randint(w)
            y1, y2 = np.clip(y - self.length // 2, 0, h), np.clip(y + self.length // 2, 0, h)
            x1, x2 = np.clip(x - self.length // 2, 0, w), np.clip(x + self.length // 2, 0, w)
            mask[y1:y2, x1:x2] = 0.
        mask = torch.from_numpy(mask).expand_as(img)
        return img * mask

# ----------------- Data Loader -----------------
def get_cifar10(batch_size=128, num_workers=10):
    transform_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2023, 0.1994, 0.2010)),
        Cutout(n_holes=1, length=16)
    ])
    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2023, 0.1994, 0.2010))
    ])
    train_data = datasets.CIFAR10('./data', train=True, transform=transform_train, download=True)
    test_data = datasets.CIFAR10('./data', train=False, transform=transform_test, download=True)
    train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True, num_workers=num_workers)
    test_loader = DataLoader(test_data, batch_size=batch_size, shuffle=False, num_workers=num_workers)
    return train_loader, test_loader

# ----------------- Evaluation -----------------
def evaluate(model, loader, device):
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for data, target in loader:
            data, target = data.to(device), target.to(device)
            outputs = model(data)
            _, predicted = outputs.max(1)
            total += target.size(0)
            correct += predicted.eq(target).sum().item()
    return 100. * correct / total

# ----------------- Training Loop -----------------
def train_model(activation, optimizer_name, lr, batch_size, batch_norm, epochs, momentum, num_workers):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = build_vgg(activation=activation, batch_norm=batch_norm).to(device)

    train_loader, test_loader = get_cifar10(batch_size=batch_size, num_workers=num_workers)
    criterion = nn.CrossEntropyLoss()

    # Optimizer setup
    if optimizer_name == 'adam':
        optimizer = optim.Adam(model.parameters(), lr=lr)
    elif optimizer_name == 'sgd':
        optimizer = optim.SGD(model.parameters(), lr=lr, momentum=momentum)
    elif optimizer_name == 'rmsprop':
        optimizer = optim.RMSprop(model.parameters(), lr=lr, momentum=momentum)
    else:
        raise ValueError("Unsupported optimizer")

    best_test_acc = 0
    os.makedirs('checkpoints', exist_ok=True)
    save_path = f'checkpoints/best_model_{activation}_{optimizer_name}_lr{lr}_bs{batch_size}.pth'

    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        for data, target in train_loader:
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()
            outputs = model(data)
            loss = criterion(outputs, target)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        train_acc = evaluate(model, train_loader, device)
        test_acc = evaluate(model, test_loader, device)

        print(f"Epoch [{epoch+1}/{epochs}] | LR={lr} | BS={batch_size} | TrainAcc={train_acc:.2f}% | TestAcc={test_acc:.2f}%")

        if test_acc > best_test_acc:
            best_test_acc = test_acc
            torch.save(model.state_dict(), save_path)

    print(f"\n✅ Finished: {activation}, {optimizer_name}, LR={lr}, BS={batch_size} | Best Test Acc: {best_test_acc:.2f}%")

# ----------------- Main Experiment -----------------
if __name__ == "__main__":
    activations = ["gelu"]
    optimizers = ["adam"]
    lrs = [0.001, 0.010]
    batch_sizes = [64, 128]
    batch_norm = True
    epochs_list = [10, 20]
    momentum = 0.9
    num_workers = 10

    for act in activations:
        for opt in optimizers:
            for lr in lrs:
                for bs in batch_sizes:
                    for ep in epochs_list:
                        train_model(act, opt, lr, bs, batch_norm, ep, momentum, num_workers)
