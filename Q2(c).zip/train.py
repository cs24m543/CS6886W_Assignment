# train.py
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from model import build_vgg
import random
import numpy as np
from PIL import Image, ImageEnhance, ImageOps
import os
import wandb
import yaml

# ----------------- Data Augmentation Classes -----------------
class Cutout(object):
    def __init__(self, n_holes, length):
        self.n_holes = n_holes
        self.length = length

    def __call__(self, img):
        h, w = img.size(1), img.size(2)
        mask = np.ones((h, w), np.float32)
        for n in range(self.n_holes):
            y, x = np.random.randint(h), np.random.randint(w)
            y1, y2 = np.clip(y - self.length // 2, 0, h), np.clip(y + self.length // 2, 0, h)
            x1, x2 = np.clip(x - self.length // 2, 0, w), np.clip(x + self.length // 2, 0, w)
            mask[y1:y2, x1:x2] = 0.
        mask = torch.from_numpy(mask).expand_as(img)
        return img * mask


class SubPolicy(object):
    def __init__(self, p1, operation1, magnitude_idx1, p2, operation2, magnitude_idx2, fillcolor=(128, 128, 128)):
        self.p1, self.p2 = p1, p2
        self.operation1, self.operation2 = operation1, operation2
        self.magnitude_idx1, self.magnitude_idx2 = magnitude_idx1, magnitude_idx2
        self.fillcolor = fillcolor

    def __call__(self, img):
        ranges = {
            "rotate": np.linspace(0, 30, 10),
            "color": np.linspace(0.0, 0.9, 10),
            "posterize": np.round(np.linspace(8, 4, 10), 0).astype(int),
            "solarize": np.linspace(256, 0, 10),
            "contrast": np.linspace(0.0, 0.9, 10),
            "sharpness": np.linspace(0.0, 0.9, 10),
            "brightness": np.linspace(0.0, 0.9, 10),
            "equalize": [0]*10,
            "invert": [0]*10
        }

        func = {
            "rotate": lambda img, mag: img.rotate(mag * random.choice([-1, 1])),
            "color": lambda img, mag: ImageEnhance.Color(img).enhance(1 + mag * random.choice([-1, 1])),
            "posterize": lambda img, mag: ImageOps.posterize(img, mag),
            "solarize": lambda img, mag: ImageOps.solarize(img, mag),
            "contrast": lambda img, mag: ImageEnhance.Contrast(img).enhance(1 + mag * random.choice([-1, 1])),
            "sharpness": lambda img, mag: ImageEnhance.Sharpness(img).enhance(1 + mag * random.choice([-1, 1])),
            "brightness": lambda img, mag: ImageEnhance.Brightness(img).enhance(1 + mag * random.choice([-1, 1])),
            "equalize": lambda img, mag: ImageOps.equalize(img),
            "invert": lambda img, mag: ImageOps.invert(img)
        }

        if random.random() < self.p1:
            img = func[self.operation1](img, ranges[self.operation1][self.magnitude_idx1])
        if random.random() < self.p2:
            img = func[self.operation2](img, ranges[self.operation2][self.magnitude_idx2])
        return img


class CIFAR10Policy(object):
    def __init__(self, fillcolor=(128, 128, 128)):
        self.policies = [
            SubPolicy(0.1, "invert", 7, 0.2, "contrast", 6, fillcolor),
            SubPolicy(0.7, "rotate", 2, 0.3, "color", 9, fillcolor),
            SubPolicy(0.8, "sharpness", 1, 0.9, "brightness", 3, fillcolor),
        ]

    def __call__(self, img):
        policy = random.choice(self.policies)
        return policy(img)

# ----------------- Data Loader -----------------
def get_cifar10(batch_size=100, num_workers=10, use_cutout=True):
    transform_list = [
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        CIFAR10Policy(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2023, 0.1994, 0.2010))
    ]
    if use_cutout:
        transform_list.append(Cutout(n_holes=1, length=16))

    transform_train = transforms.Compose(transform_list)
    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2023, 0.1994, 0.2010))
    ])

    train_data = datasets.CIFAR10('./data', train=True, transform=transform_train, download=True)
    test_data = datasets.CIFAR10('./data', train=False, transform=transform_test, download=True)

    train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True, num_workers=num_workers)
    test_loader = DataLoader(test_data, batch_size=batch_size, shuffle=False, num_workers=num_workers)
    return train_loader, test_loader


# ----------------- Evaluation -----------------
def evaluate(model, loader, device):
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for data, target in loader:
            data, target = data.to(device), target.to(device)
            outputs = model(data)
            _, predicted = outputs.max(1)
            total += target.size(0)
            correct += predicted.eq(target).sum().item()
    return 100. * correct / total


# ----------------- Training -----------------
def train_model(config=None):
    with wandb.init(config=config):
        config = wandb.config

        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        model = build_vgg(activation=config.activation, batch_norm=config.batch_norm).to(device)

        train_loader, test_loader = get_cifar10(
            batch_size=config.batch_size,
            num_workers=config.num_workers,
            use_cutout=True
        )

        criterion = nn.CrossEntropyLoss()

        # Optimizer setup
        if config.optimizer == 'adam':
            optimizer = optim.Adam(model.parameters(), lr=config.lr)
        elif config.optimizer == 'nadam':
            optimizer = optim.Nadam(model.parameters(), lr=config.lr)
        elif config.optimizer == 'sgd':
            optimizer = optim.SGD(model.parameters(), lr=config.lr, momentum=config.momentum)
        elif config.optimizer == 'nesterov-sgd':
            optimizer = optim.SGD(model.parameters(), lr=config.lr, momentum=config.momentum, nesterov=True)
        elif config.optimizer == 'adagrad':
            optimizer = optim.Adagrad(model.parameters(), lr=config.lr)
        elif config.optimizer == 'rmsprop':
            optimizer = optim.RMSprop(model.parameters(), lr=config.lr, momentum=config.momentum)
        else:
            raise ValueError(f"Unknown optimizer: {config.optimizer}")

        best_test_acc = 0
        os.makedirs('checkpoints', exist_ok=True)
        save_path = f'checkpoints/best_model_{config.activation}_{config.optimizer}.pth'

        for epoch in range(config.epochs):
            model.train()
            running_loss = 0.0
            for data, target in train_loader:
                data, target = data.to(device), target.to(device)
                optimizer.zero_grad()
                outputs = model(data)
                loss = criterion(outputs, target)
                loss.backward()
                optimizer.step()
                running_loss += loss.item()

            # Evaluate train and test accuracy
            train_acc = evaluate(model, train_loader, device)
            test_acc = evaluate(model, test_loader, device)

            wandb.log({
                "epoch": epoch + 1,
                "train_loss": running_loss / len(train_loader),
                "train_accuracy": train_acc,
                "test_accuracy": test_acc
            })

            print(f"Epoch {epoch+1}/{config.epochs} | Act: {config.activation} | Opt: {config.optimizer} | "
                  f"LR: {config.lr} | TrainAcc: {train_acc:.2f}% | TestAcc: {test_acc:.2f}%")

            if test_acc > best_test_acc:
                best_test_acc = test_acc
                torch.save(model.state_dict(), save_path)

        print(f"\n✅ Best Test Accuracy ({config.activation}, {config.optimizer}): {best_test_acc:.2f}%")
        wandb.log({"best_test_accuracy": best_test_acc})


# ----------------- Sweep Entry Point -----------------
if __name__ == "__main__":
    with open("sweep.yaml", "r") as f:
        sweep_config = yaml.safe_load(f)
    sweep_id = wandb.sweep(sweep_config, project="cifar10-sweep")
    wandb.agent(sweep_id, function=train_model)
