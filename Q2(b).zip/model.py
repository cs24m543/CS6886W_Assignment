# model.py
import torch
import torch.nn as nn

cfg_vgg6 = [64, 64, 'M', 128, 128, 'M']

def get_activation(name):
    name = name.lower()
    if name == 'relu':
        return nn.ReLU(inplace=True)
    elif name == 'sigmoid':
        return nn.Sigmoid()
    elif name == 'tanh':
        return nn.Tanh()
    elif name == 'silu':
        return nn.SiLU(inplace=True)
    elif name == 'gelu':
        return nn.GELU()
    else:
        raise ValueError(f"Unsupported activation: {name}")

class VGG(nn.Module):
    def __init__(self, cfg=cfg_vgg6, activation='relu', num_classes=10, batch_norm=True):
        super(VGG, self).__init__()
        self.features = self.make_layers(cfg, activation, batch_norm)
        self.classifier = nn.Sequential(nn.Linear(128, num_classes))

    def make_layers(self, cfg, activation, batch_norm):
        layers = []
        in_channels = 3
        for v in cfg:
            if v == 'M':
                layers.append(nn.MaxPool2d(kernel_size=2, stride=2))
            else:
                conv2d = nn.Conv2d(in_channels, v, kernel_size=3, padding=1)
                if batch_norm:
                    layers += [conv2d, nn.BatchNorm2d(v), get_activation(activation)]
                else:
                    layers += [conv2d, get_activation(activation)]
                in_channels = v
        layers.append(nn.AdaptiveAvgPool2d((1, 1)))
        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        return self.classifier(x)
