import argparse
import torch
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from model import VGG, cfg_vgg6

def evaluate(model, loader, device):
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for data, target in loader:
            data, target = data.to(device), target.to(device)
            outputs = model(data)
            _, predicted = outputs.max(1)
            total += target.size(0)
            correct += predicted.eq(target).sum().item()
    return 100. * correct / total

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test VGG model with different optimizers")
    parser.add_argument('--optimizer', type=str, required=True,
                        help="Name of the optimizer (e.g. Adam, SGD, Nesterov, RMSprop)")
    args = parser.parse_args()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914,0.4822,0.4465),(0.2023,0.1994,0.2010))
    ])
    testset = torchvision.datasets.CIFAR10(root='./data', train=False, download=True, transform=transform_test)
    test_loader = DataLoader(testset, batch_size=128, shuffle=False, num_workers=4)

    optimizer_name = args.optimizer
    model = VGG(cfg_vgg6, activation='relu')
    model.load_state_dict(torch.load(f"vgg6_{optimizer_name}.pth", map_location=device, weights_only=True))
    model = model.to(device)

    test_acc = evaluate(model, test_loader, device)
    print(f"Test Accuracy with {optimizer_name}: {test_acc:.2f}%")
