
1.Run the following command in cmd to find performance of each optimizer
python test.py --optimizer Adam
python test.py --optimizer SGD
python test.py --optimizer Nesterov
python test.py --optimizer RMSprop
python test.py --optimizer NAdam
python test.py --optimizer Adagrad